﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using CMS.Entity;
using CMS.Exception;
using CMS.DAL;
using System.Data;

namespace CMS.BL
{
    /// <summary>
    /// 
    /// </summary>
    public class CustomerBL
    {
        public static bool ValidateCustomer(Customer newCust)
        {
            StringBuilder message = new StringBuilder();
            bool validCustomer = true;

            try 
            {
                if (newCust.Name == string.Empty)
                {
                    message.Append("Customer name should be provided\n");
                    validCustomer = false;
                }
                else if (!Regex.IsMatch(newCust.Name, "^[A-Z][a-z]+"))
                {
                    message.Append("Customer name should start with Capital letter and it should have alphabets only\n");
                    validCustomer = false;
                }

                if (newCust.City == string.Empty)
                {
                    message.Append("City should be provided\n");
                    validCustomer = false;
                }

                if (newCust.Age < 18)
                {
                    message.Append("Age should be greater that or equal to 18\n");
                    validCustomer = false;
                }

                if (newCust.Phone == String.Empty)
                {
                    message.Append("Phone number should be provided\n");
                    validCustomer = false;
                }
                else if (!Regex.IsMatch(newCust.Phone, "[7-9][0-9]{9}"))
                {
                    message.Append("Phone number should start with 7 or 8 or 9 and it should have exactly 10 digits\n");
                    validCustomer = false;
                }

                if (newCust.Pincode == string.Empty)
                {
                    message.Append("Pincode should be provided\n");
                    validCustomer = false;
                }
                else if (!Regex.IsMatch(newCust.Pincode, "[1-9][0-9]{5}"))
                {
                    message.Append("Pincode should have exactly 6 digits\n");
                    validCustomer = false;
                }

                if (validCustomer == false)
                {
                    throw new CustomerException(message.ToString());
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validCustomer;
        }

        public static int InsertCustomer(Customer newCust)
        {
            int custInserted = 0;

            try 
            {
                if (ValidateCustomer(newCust))
                {
                    custInserted = CustomerDAL.InsertCustomer(newCust);
                }
                else
                    throw new CustomerException("Customer data is invalid");
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custInserted;
        }

        public static int UpdateCustomer(Customer custToBeUpdated)
        {
            int custUpdated = 0;

            try 
            {
                if (ValidateCustomer(custToBeUpdated))
                {
                    custUpdated = CustomerDAL.UpdateCustomer(custToBeUpdated);
                }
                else
                {
                    throw new CustomerException("Invalid Customer data for updation");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custUpdated;
        }

        public static int DeleteCustomer(int custID)
        {
            int custDeleted = 0;

            try 
            {
                custDeleted = CustomerDAL.DeleteCustomer(custID);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custDeleted;
        }

        public static Customer SearchCustomer(int custID)
        {
            Customer custSearched = null;

            try 
            {
                custSearched = CustomerDAL.SearchCustomer(custID);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custSearched;
        }

        public static DataTable DisplayCustomer()
        {
            DataTable dtCust = null;

            try 
            {
                dtCust = CustomerDAL.DisplayCustomer();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return dtCust;
        }
    }
}
