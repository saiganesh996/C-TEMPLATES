﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMS.Entity;
using CMS.Exception;
using CMS.BL;
using System.Data;

namespace CMS.WPFPL
{
    /// <summary>
    /// Interaction logic for Display.xaml
    /// </summary>
    public partial class Display : Window
    {
        public Display()
        {
            InitializeComponent();
        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            DataTable dtCust = CustomerBL.DisplayCustomer();

            if (dtCust.Rows.Count > 0)
            {
                dgCustomer.DataContext = dtCust;
            }
            else
                MessageBox.Show("Data not Available");
        }
    }
}
