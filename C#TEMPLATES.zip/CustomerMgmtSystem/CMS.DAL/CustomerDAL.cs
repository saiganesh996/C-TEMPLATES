﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using CMS.Entity;       //Reference for Customer Entity
using CMS.Exception;    //Reference for Customer Exception

namespace CMS.DAL
{
    /// <summary>
    /// 
    /// </summary>
    public class CustomerDAL
    {
        //Function to create the command object with connection
        public static SqlCommand CreateCommand()
        {
            SqlCommand cmd = null;

            try 
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = @"Data Source=PUNHWL15495\SQL2012;Database=Training;uid=sqluser;pwd=sqluser";

                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }

            return cmd;
        }

        public static DataTable DisplayCustomer()
        {
            DataTable dtCust = new DataTable();

            try 
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "usp_DisplayCustomer";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                dtCust.Load(dr);
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return dtCust;
        }

        public static Customer SearchCustomer(int custID)
        {
            Customer searchedCustomer = null;

            try 
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "usp_SearchCustomer";

                cmd.Parameters.AddWithValue("@CustID", custID);

                cmd.Connection.Open();
                SqlDataReader drCust = cmd.ExecuteReader();
                if (drCust.HasRows)
                {
                    searchedCustomer = new Customer();
                    drCust.Read();
                    searchedCustomer.CustomerID = Convert.ToInt32(drCust["CustomerID"]);
                    searchedCustomer.Name = drCust["Name"].ToString();
                    searchedCustomer.City = drCust["City"].ToString();
                    searchedCustomer.Age = Convert.ToInt32(drCust["Age"]);
                    searchedCustomer.Phone = drCust["Phone"].ToString();
                    searchedCustomer.Pincode = drCust["Pincode"].ToString();
                }
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return searchedCustomer;
        }

        public static int InsertCustomer(Customer newCust)
        {
            int custInserted = 0;
            try 
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "usp_InsertCustomer";

                cmd.Parameters.AddWithValue("@Name", newCust.Name);
                cmd.Parameters.AddWithValue("@City", newCust.City);
                cmd.Parameters.AddWithValue("@Age", newCust.Age);
                cmd.Parameters.AddWithValue("@Phone", newCust.Phone);
                cmd.Parameters.AddWithValue("@Pincode", newCust.Pincode);

                cmd.Connection.Open();
                custInserted = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custInserted;
        }

        public static int UpdateCustomer(Customer custToBeUpdated)
        {
            int custUpdated = 0;

            try 
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "usp_UpdateCustomer";

                cmd.Parameters.AddWithValue("@CustID", custToBeUpdated.CustomerID);
                cmd.Parameters.AddWithValue("@Name", custToBeUpdated.Name);
                cmd.Parameters.AddWithValue("@City", custToBeUpdated.City);
                cmd.Parameters.AddWithValue("@Age", custToBeUpdated.Age);
                cmd.Parameters.AddWithValue("@Phone", custToBeUpdated.Phone);
                cmd.Parameters.AddWithValue("@Pincode", custToBeUpdated.Pincode);

                cmd.Connection.Open();
                custUpdated = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custUpdated;
        }

        public static int DeleteCustomer(int custID)
        {
            int custDeleted = 0;

            try 
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "usp_DeleteCustomer";

                cmd.Parameters.AddWithValue("@CustID", custID);

                cmd.Connection.Open();
                custDeleted = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custDeleted;
        }
    }
}
