﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CMS.Entity;
using CMS.Exception;
using CMS.BL;

namespace CMS.PL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void Clear()
        {
            txtCustName.Text = "";
            txtCustID.Text = "";
            txtCity.Text = "";
            txtAge.Text = "";
            txtPhone.Text = "";
            txtPincode.Text = "";

            btnDelete.Enabled = false;
            btnUpdate.Enabled = false;
        }

        public void Display()
        {
            try 
            {
                DataTable dtCust = CustomerBL.DisplayCustomer();

                if (dtCust.Rows.Count > 0)
                {
                    dgvCustomer.DataSource = dtCust;
                }
                else
                    throw new CustomerException("Customer Records Unavailable");
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            Display();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            Customer newCust = new Customer();

            try 
            {
                newCust.Name = txtCustName.Text;
                newCust.City = txtCity.Text;
                newCust.Age = Convert.ToInt32(txtAge.Text);
                newCust.Phone = txtPhone.Text;
                newCust.Pincode = txtPincode.Text;

                int custInserted = CustomerBL.InsertCustomer(newCust);

                if (custInserted > 0)
                {
                    MessageBox.Show("Customer Record Inserted Successfully");
                    Clear();
                    Display();
                }
                else
                    throw new CustomerException("Customer record not inserted");
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try 
            {
                Customer cust = new Customer();

                cust = CustomerBL.SearchCustomer(Convert.ToInt32(txtCustID.Text));

                if (cust != null)
                {
                    txtCustName.Text = cust.Name;
                    txtCity.Text = cust.City;
                    txtAge.Text = cust.Age.ToString();
                    txtPhone.Text = cust.Phone;
                    txtPincode.Text = cust.Pincode;

                    btnUpdate.Enabled = true;
                    btnDelete.Enabled = true;
                }
                else
                    throw new CustomerException("Customer not found with ID : " + txtCustID.Text);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try 
            {
                Customer cust = new Customer();
                cust.CustomerID = Convert.ToInt32(txtCustID.Text);
                cust.Name = txtCustName.Text;
                cust.City = txtCity.Text;
                cust.Age = Convert.ToInt32(txtAge.Text);
                cust.Pincode = txtPincode.Text;
                cust.Phone = txtPhone.Text;

                int custUpdated = CustomerBL.UpdateCustomer(cust);

                if (custUpdated > 0)
                {
                    MessageBox.Show("Customer Record Updated Successfully");
                    Clear();
                    Display();
                }
                else
                {
                    throw new CustomerException("Customer Record not Updated");
                }
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try 
            {
                int custDeleted = CustomerBL.DeleteCustomer(Convert.ToInt32(txtCustID.Text));

                if (custDeleted > 0)
                {
                    MessageBox.Show("Customer Record Deleted Successfully");
                    Clear();
                    Display();
                }
                else
                {
                    throw new CustomerException("Customer Record not Deleted");
                }
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
