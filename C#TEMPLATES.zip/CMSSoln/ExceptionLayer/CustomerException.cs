﻿using System;

namespace ExceptionLayer
{
    public class CustomerException : ApplicationException
    {
        public CustomerException()
            : base()
        { }

        public CustomerException(string message)
            : base(message)
        { }
    }
}
