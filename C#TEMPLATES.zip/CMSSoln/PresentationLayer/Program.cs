﻿using BusinessLogicLayer;
using EntityLayer;
using ExceptionLayer;
using System;
using System.Collections.Generic;


namespace PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.Write("Enter your Choice: [ ]\b\b");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddCustomer();
                        break;
                    case 2:
                        ListAllCustomers();
                        break;
                    case 3:
                        SearchCustomerByID();
                        break;
                    case 4:
                        UpdateCustomer();
                        break;
                    case 5:
                        DeleteCustomer();
                        break;
                    case 0:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
                Console.ReadKey();
                Console.Clear();
            } while (choice != -1);
        }

        private static void DeleteCustomer()
        {
            try
            {
                ListAllCustomers();
                Console.WriteLine();
                int deleteCustomerID;
                Console.Write("Enter CustomerID to Delete: ");
                deleteCustomerID = Convert.ToInt32(Console.ReadLine());
                Customer deleteCustomer = CustomerBL.SearchCustomerBL(deleteCustomerID);
                if (deleteCustomer != null)
                {
                    bool Customerdeleted = CustomerBL.DeleteCustomerBL(deleteCustomerID);
                    if (Customerdeleted)
                        Console.WriteLine("Customer Deleted");
                    else
                        Console.WriteLine("Customer not Deleted ");
                }
                else
                {
                    Console.WriteLine("No Customer Details Available");
                }


            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdateCustomer()
        {
            try
            {
                ListAllCustomers();
                Console.WriteLine();
                int updateCustomerID;
                Console.Write("Enter CustomerID to Update Details: ");
                updateCustomerID = Convert.ToInt32(Console.ReadLine());
                Customer updatedCustomer = CustomerBL.SearchCustomerBL(updateCustomerID);
                if (updatedCustomer != null)
                {
                    Console.Write("Update Customer Name : ");
                    updatedCustomer.Name = Console.ReadLine();
                    Console.Write("Update Customer City : ");
                    updatedCustomer.City = Console.ReadLine();
                    Console.Write("Update Customer Age : ");
                    updatedCustomer.Age = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Update PhoneNumber : ");
                    updatedCustomer.Phone = Console.ReadLine();
                    Console.Write("Update Customer Pincode : ");
                    updatedCustomer.Pincode = Console.ReadLine();

                    bool CustomerUpdated = CustomerBL.UpdateCustomerBL(updatedCustomer);
                    if (CustomerUpdated)
                        Console.WriteLine("Customer Details Updated");
                    else
                        Console.WriteLine("Customer Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No Customer Details Available");
                }


            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchCustomerByID()
        {
            try
            {
                int searchCustomerID;
                Console.Write("Enter CustomerID to Search: ");
                searchCustomerID = Convert.ToInt32(Console.ReadLine());
                Customer searchCustomer = CustomerBL.SearchCustomerBL(searchCustomerID);
                if (searchCustomer != null)
                {
                    Console.WriteLine("----------------------------------------------------------------------------------------------------------------------");
                    Console.WriteLine("CustomerID | Name \t\t|City \t\t| Age \t| Phone Number\t\t|Pincode");
                    Console.WriteLine("----------------------------------------------------------------------------------------------------------------------");
                    Console.WriteLine("{0,-10} |{1,-10} \t\t|{2,-10}\t|{3,-5}   |{4,-10}\t\t|{5,-10}",
                        searchCustomer.CustomerID, searchCustomer.Name, searchCustomer.City,searchCustomer.Age,searchCustomer.Phone,searchCustomer.Pincode);
                    Console.WriteLine("----------------------------------------------------------------------------------------------------------------------");
                }
                else
                {
                    Console.WriteLine("No Customer Details Available");
                }

            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        private static void ListAllCustomers()
        {
            try
            {
                List<Customer> CustomerList = CustomerBL.GetAllCustomersBL();
                if (CustomerList != null)
                {
                    Console.WriteLine("----------------------------------------------------------------------------------------------------------------------");
                    Console.WriteLine("CustomerID | Name \t\t|City \t\t| Age \t| Phone Number\t\t|Pincode");
                    Console.WriteLine("----------------------------------------------------------------------------------------------------------------------");
                    foreach (Customer customer in CustomerList)
                    {
                        Console.WriteLine("{0,-10} |{1,-10} \t\t|{2,-10}\t|{3,-5}   |{4,-10}\t\t|{5,-10}",
                       customer.CustomerID, customer.Name, customer.City, customer.Age, customer.Phone, customer.Pincode);
                    }
                    Console.WriteLine("----------------------------------------------------------------------------------------------------------------------");

                }
                else
                {
                    Console.WriteLine("No Customer Details Available");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddCustomer()
        {
            try
            {
                Customer newCustomer = new Customer();
                Console.Write("Enter CustomerID : ");
                newCustomer.CustomerID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Customer Name : ");
                newCustomer.Name = Console.ReadLine();
                Console.Write("Enter Customer City : ");
                newCustomer.City = Console.ReadLine();
                Console.Write("Enter Customer Age : ");
                newCustomer.Age = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter PhoneNumber : ");
                newCustomer.Phone = Console.ReadLine();
                Console.Write("Enter Customer Pincode : ");
                newCustomer.Pincode = Console.ReadLine();

                bool CustomerAdded = CustomerBL.AddCustomerBL(newCustomer);
                if (CustomerAdded)
                    Console.WriteLine("Customer Added");
                else
                    Console.WriteLine("Customer not Added");
            }
            catch (CustomerException ex)
            {
                Console.WriteLine("\n Errors:\n"+ex.Message);
            }
        }

        private static void PrintMenu()
        {
            Console.WriteLine("\n-----------Customer PhoneBook Menu-----------");
            Console.WriteLine("1. Add Customer");
            Console.WriteLine("2. List All Customers");
            Console.WriteLine("3. Search Customer by ID");
            Console.WriteLine("4. Update Customer");
            Console.WriteLine("5. Delete Customer");
            Console.WriteLine("0. Exit");
            Console.WriteLine("------------------------------------------\n");

        }
    }
}
