﻿using EntityLayer;
using ExceptionLayer;
using System;
using System.Collections.Generic;


namespace DataAccessLayer
{
    public class CustomerDAL
    {
        public static List<Customer> CustomerList = new List<Customer>();

        public bool AddCustomerDAL(Customer newCustomer)
        {
            bool CustomerAdded = false;
            try
            {
                CustomerList.Add(newCustomer);
                CustomerAdded = true;
            }
            catch (SystemException ex)
            {
                throw new CustomerException(ex.Message);
            }
            return CustomerAdded;

        }

        public List<Customer> GetAllCustomersDAL()
        {
            return CustomerList;
        }

        public Customer SearchCustomerDAL(int searchCustomerID)
        {
            Customer searchCustomer = null;
            try
            {
                searchCustomer = CustomerList.
                    Find(Customer => Customer.CustomerID == searchCustomerID);
            }
            catch (SystemException ex)
            {
                throw new CustomerException(ex.Message);
            }
            return searchCustomer;
        }

        public bool UpdateCustomerDAL(Customer updateCustomer)
        {
            bool CustomerUpdated = false;
            try
            {
                for (int i = 0; i < CustomerList.Count; i++)
                {
                    if (CustomerList[i].CustomerID == updateCustomer.CustomerID)
                    {
                        updateCustomer.Name = CustomerList[i].Name;
                        updateCustomer.City = CustomerList[i].City;
                        updateCustomer.Age = CustomerList[i].Age;
                        updateCustomer.Phone = CustomerList[i].Phone;
                        updateCustomer.Pincode = CustomerList[i].Pincode;
                        CustomerUpdated = true;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new CustomerException(ex.Message);
            }
            return CustomerUpdated;

        }

        public bool DeleteCustomerDAL(int deleteCustomerID)
        {
            bool CustomerDeleted = false;
            try
            {
                Customer deleteCustomer = CustomerList
                    .Find(Customer => Customer.CustomerID == deleteCustomerID);

                if (deleteCustomer != null)
                {
                    CustomerList.Remove(deleteCustomer);
                    CustomerDeleted = true;
                }
            }
            catch (SystemException ex)
            {
                throw new CustomerException(ex.Message);
            }
            return CustomerDeleted;

        }
    }
}
