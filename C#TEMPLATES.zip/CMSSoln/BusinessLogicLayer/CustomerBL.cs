﻿using EntityLayer;
using ExceptionLayer;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using DataAccessLayer;
namespace BusinessLogicLayer
{
    public class CustomerBL
    {
        public static bool ValidateCustomer(Customer newCust)
        {
            StringBuilder message = new StringBuilder();
            bool validCustomer = true;

            try
            {
                if (!(newCust.CustomerID >=101 && newCust.CustomerID<=110))
                {
                    message.Append("Customer ID must be between 101 and 110\n");
                    validCustomer = false;
                }
                if (newCust.Name == string.Empty)
                {
                    message.Append("Customer name should be provided\n");
                    validCustomer = false;
                }
                else if (!Regex.IsMatch(newCust.Name, "^[A-Z][a-z]+"))
                {
                    message.Append("Customer name should start with Capital letter and it should have alphabets only\n");
                    validCustomer = false;
                }

                if (newCust.City == string.Empty)
                {
                    message.Append("City should be provided\n");
                    validCustomer = false;
                }

                if (newCust.Age < 18 || newCust.Age>100)
                {
                    message.Append("Age should be greater than or equal to 18\n");
                    validCustomer = false;
                }

                if (newCust.Phone == String.Empty)
                {
                    message.Append("Phone number should be provided\n");
                    validCustomer = false;
                }
                else if (!Regex.IsMatch(newCust.Phone, "[6-9][0-9]{9}"))
                {
                    message.Append("Phone number should start with 6 or 7 or 8 or 9 and it should have exactly 10 digits\n");
                    validCustomer = false;
                }

                if (newCust.Pincode == string.Empty)
                {
                    message.Append("Pincode should be provided\n");
                    validCustomer = false;
                }
                else if (!Regex.IsMatch(newCust.Pincode, "[1-9][0-9]{5}"))
                {
                    message.Append("Pincode should have exactly 6 digits\n");
                    validCustomer = false;
                }

                if (validCustomer == false)
                {
                    throw new CustomerException(message.ToString());
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validCustomer;
        }
        public static bool AddCustomerBL(Customer newCustomer)
        {
            bool CustomerAdded = false;
            try
            {
                if (ValidateCustomer(newCustomer))
                {
                    CustomerDAL CustomerDAL = new CustomerDAL();
                    CustomerAdded = CustomerDAL.AddCustomerDAL(newCustomer);
                }
            }
            catch (CustomerException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return CustomerAdded;
        }

        public static List<Customer> GetAllCustomersBL()
        {
            List<Customer> CustomerList = null;
            try
            {
                CustomerDAL CustomerDAL = new CustomerDAL();
                CustomerList = CustomerDAL.GetAllCustomersDAL();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CustomerList;
        }

        public static Customer SearchCustomerBL(int searchCustomerID)
        {
            Customer searchCustomer = null;
            try
            {
                CustomerDAL CustomerDAL = new CustomerDAL();
                searchCustomer = CustomerDAL.SearchCustomerDAL(searchCustomerID);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchCustomer;

        }

        public static bool UpdateCustomerBL(Customer updateCustomer)
        {
            bool CustomerUpdated = false;
            try
            {
                if (ValidateCustomer(updateCustomer))
                {
                    CustomerDAL CustomerDAL = new CustomerDAL();
                    CustomerUpdated = CustomerDAL.UpdateCustomerDAL(updateCustomer);
                }
            }
            catch (CustomerException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return CustomerUpdated;
        }

        public static bool DeleteCustomerBL(int deleteCustomerID)
        {
            bool CustomerDeleted = false;
            try
            {
                if (deleteCustomerID > 0)
                {
                    CustomerDAL CustomerDAL = new CustomerDAL();
                    CustomerDeleted = CustomerDAL.DeleteCustomerDAL(deleteCustomerID);
                }
                else
                {
                    throw new CustomerException("Invalid Customer ID");
                }
            }
            catch (CustomerException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return CustomerDeleted;
        }

    }
}
