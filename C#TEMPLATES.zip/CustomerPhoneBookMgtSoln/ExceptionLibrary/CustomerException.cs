﻿using System;

namespace ExceptionLibrary
{
    // Step1: Derive From ApplicationException class
    public class CustomerException
        :ApplicationException
    {
        // Step2: Create Parameterized Constructor
        // and pass message to Base class constructor
        public CustomerException(string message)
            :base(message)
        {

        }
        // default constructor
        public CustomerException()
        {

        }
    }
}
