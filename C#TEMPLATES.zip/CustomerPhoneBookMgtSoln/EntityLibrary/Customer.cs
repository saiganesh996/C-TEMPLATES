﻿

namespace EntityLibrary
{
    // Customer Entity class
    public class Customer
    {
        // Properties
        public int CustomerId { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string City { get; set; }
        public string MobileNumber { get; set; }
        public string PinCode { get; set; }
    }
}
